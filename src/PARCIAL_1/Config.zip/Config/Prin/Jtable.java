
package PARCIAL_1.Config.Prin;

import PARCIAL_1.Config.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Jtable extends javax.swing.JFrame {

    Conexion conl= new Conexion();
    Connection conet;
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs;
    int idc;
    int selectedRowIndex; // Variable para almacenar el índice de la fila seleccionada
    
    public Jtable() {
        initComponents();
        setLocationRelativeTo(null);
        consultar();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnAgregar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        txtCod = new javax.swing.JTextField();
        txtPrec = new javax.swing.JTextField();
        JLAL1 = new javax.swing.JLabel();
        txtNom = new javax.swing.JTextField();
        txtCant = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtFech = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                formMouseClicked(evt);
            }
        });

        jLabel1.setText("CANTIDAD:");

        jLabel2.setText("NOMBRE:");

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.setToolTipText("");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        txtPrec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecActionPerformed(evt);
            }
        });

        JLAL1.setText("                                                               ");

        jLabel5.setText("PRECIO:");

        jLabel6.setText("CODIGO:");

        jLabel7.setText("                              FERRETERIA JEED");

        jLabel3.setText("FECHA:");

        txtFech.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechActionPerformed(evt);
            }
        });

        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Codigo", "Nombre", "Precio", "Cantidad", "Fecha"
            }
        ));
        Tabla.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane3.setViewportView(Tabla);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane3)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(JLAL1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(25, 25, 25)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtNom, javax.swing.GroupLayout.DEFAULT_SIZE, 334, Short.MAX_VALUE)
                                        .addComponent(txtPrec, javax.swing.GroupLayout.DEFAULT_SIZE, 334, Short.MAX_VALUE)
                                        .addComponent(txtCant))
                                    .addComponent(txtCod, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(459, 459, 459)
                                .addComponent(txtFech, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(btnAgregar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnModificar)))
                        .addGap(111, 111, 111)
                        .addComponent(btnEliminar)
                        .addGap(97, 97, 97)
                        .addComponent(btnNuevo)
                        .addGap(63, 63, 63))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLAL1)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPrec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtFech, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar)
                    .addComponent(btnNuevo)
                    .addComponent(btnAgregar))
                .addGap(31, 31, 31)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        Nuevo();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        Agregar();
        consultar();
        Nuevo();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void txtPrecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecActionPerformed

    private void txtFechActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechActionPerformed

    private void formMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseClicked
        seleccionarFila();


    }//GEN-LAST:event_formMouseClicked

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        Modificar();
        consultar();
        Nuevo();
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        Eliminar();
        consultar();
        Nuevo();
    }//GEN-LAST:event_btnEliminarActionPerformed

    
    private void seleccionarFila() {
        int fila = Tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "No se seleccionó una fila");
        } else {
            selectedRowIndex = fila; // Almacena el índice de la fila seleccionada
            txtCod.setText(Tabla.getValueAt(fila, 0).toString());
            txtNom.setText(Tabla.getValueAt(fila, 1).toString());
            txtPrec.setText(Tabla.getValueAt(fila, 2).toString());
            txtCant.setText(Tabla.getValueAt(fila, 3).toString());

            // Convierte la fecha de la tabla al formato deseado y establece el valor en el campo de texto
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // Usa el formato de tu tabla
            Date date = (Date) Tabla.getValueAt(fila, 4);
            txtFech.setText(sdf.format(date));
        }
    }

 
    
    
    void Modificar() {
    String nom = txtNom.getText();
    String prec = txtPrec.getText();
    String cant = txtCant.getText();
    String fechaTexto = txtFech.getText();

    if (nom.isEmpty() || prec.isEmpty() || cant.isEmpty() || fechaTexto.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
        return;
    }

    try {
        // Validar que los campos numéricos sean números válidos
        float precio = Float.parseFloat(prec);
        int cantidad = Integer.parseInt(cant);

        // Validar y convertir la fecha al formato deseado ("yyyy-MM-dd")
        SimpleDateFormat sdfIngreso = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfBaseDatos = new SimpleDateFormat("yyyy-MM-dd");

        Date fecha = sdfIngreso.parse(fechaTexto);
        String fechaFormateada = sdfBaseDatos.format(fecha);

        // Obtener el código de producto seleccionado de la tabla
        int fila = Tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "No se seleccionó una fila");
            return;
        }
        String cod = Tabla.getValueAt(fila, 0).toString();

        String sql = "UPDATE bdnegocio.producto SET nombreProducto = '" + nom + "', precioUnitario = " + precio + ", cantidadProducto = " + cantidad + ", fechaVencimiento = '" + fechaFormateada + "' WHERE codigoProducto = " + cod;

        conet = conl.getConnection();
        st = conet.createStatement();
        st.executeUpdate(sql);

        JOptionPane.showMessageDialog(null, "Producto Modificado Exitosamente!");
        consultar(); // Actualiza la tabla después de modificar el producto
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "El precio y la cantidad deben ser números válidos.");
    } catch (ParseException e) {
        JOptionPane.showMessageDialog(null, "Fecha no válida. Utilice el formato dd/MM/yyyy.");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar el producto en la base de datos: " + e.getMessage());
    } finally {
        try {
            if (st != null) {
                st.close();
            }
            if (conet != null) {
                conet.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}


    

    // Actualiza la tabla después de modificar o eliminar un producto
    private void actualizarTabla() {
        consultar();
        Nuevo();
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Jtable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Jtable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Jtable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Jtable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Jtable().setVisible(true);
            }
        });
    }
    
    void consultar() {
    String sql = "select * from bdnegocio.producto";

    try {
        conet = conl.getConnection();
        st = conet.createStatement();
        rs = st.executeQuery(sql);
        Object[] producto = new Object[5];

        modelo = (DefaultTableModel) Tabla.getModel();
        modelo.setRowCount(0); // Limpiar el modelo antes de agregar nuevos datos

        while (rs.next()) {
            producto = new Object[5];
            producto[0] = rs.getString("codigoProducto");
            producto[1] = rs.getString("nombreProducto");
            producto[2] = rs.getFloat("precioUnitario");
            producto[3] = rs.getInt("cantidadProducto");
            producto[4] = rs.getDate("fechaVencimiento");

            modelo.addRow(producto);
        }
        Tabla.setModel(modelo);
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conet != null) {
                conet.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

void Agregar() {
    String cod = txtCod.getText();
    String nom = txtNom.getText();
    String prec = txtPrec.getText();
    String cant = txtCant.getText();
    String fechaTexto = txtFech.getText();

    if (cod.isEmpty() || nom.isEmpty() || prec.isEmpty() || cant.isEmpty() || fechaTexto.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
        return;
    }

    try {
        // Validar que los campos numéricos sean números válidos
        float precio = Float.parseFloat(prec);
        int cantidad = Integer.parseInt(cant);

        // Validar y convertir la fecha
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date fecha = null;

        try {
            fecha = sdf.parse(fechaTexto);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Fecha no válida. Utilice el formato dd/MM/yyyy.");
            return;
        }

        String sql = "INSERT INTO bdnegocio.producto (codigoProducto, nombreProducto, precioUnitario, cantidadProducto, fechaVencimiento) VALUES ('" + cod + "', '" + nom + "', " + precio + ", " + cantidad + ", '" + sdf.format(fecha) + "');";

        conet = conl.getConnection();
        st = conet.createStatement();
        st.executeUpdate(sql);

        JOptionPane.showMessageDialog(null, "Producto Registrado Exitosamente!");
        consultar(); // Actualiza la tabla después de agregar el producto
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "El precio y la cantidad deben ser números válidos.");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al agregar el producto a la base de datos: " + e.getMessage());
    } finally {
        try {
            if (st != null) {
                st.close();
            }
            if (conet != null) {
                conet.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

    void limpiarTabla(){
        for(int i = 0; i <= Tabla.getRowCount(); i++){
            modelo.removeRow(i);
            i = i - 1;
        }
    }

    void Eliminar() {
    int fila = Tabla.getSelectedRow();
    try {
        if (fila < 0) {
            JOptionPane.showMessageDialog(null, "Producto no Seleccionado");
            limpiarTabla();
        } else {
            // Obtener el valor de idc desde la fila seleccionada
            String codigoProducto = Tabla.getValueAt(fila, 0).toString();
            int idProducto = Integer.parseInt(codigoProducto);
            
            // Luego puedes utilizar idProducto en tu consulta SQL para eliminar el producto
            String sql = "DELETE FROM bdnegocio.producto WHERE codigoProducto = " + idProducto;
            
            conet = conl.getConnection();
            st = conet.createStatement();
            st.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Producto Eliminado");
            limpiarTabla();
        }
    } catch (Exception e) {
        // Manejar la excepción adecuadamente
    }
}

    void Nuevo(){
        txtCod.setText("");
        txtNom.setText("");
        txtPrec.setText("");
        txtCant.setText("");
        txtFech.setText("");
    }


    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JLAL1;
    private javax.swing.JTable Tabla;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtCant;
    private javax.swing.JTextField txtCod;
    private javax.swing.JTextField txtFech;
    private javax.swing.JTextField txtNom;
    private javax.swing.JTextField txtPrec;
    // End of variables declaration//GEN-END:variables
}
